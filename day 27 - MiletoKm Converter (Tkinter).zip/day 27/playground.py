def add(*args):
    sum=0
    for n in args:
        sum+=n
    return sum
print(add(1,2,3))

def cal(n,**kwargs):
    print(kwargs)
    # for key,value in kwargs.items():
    #     print(key)
    n+=kwargs["add"]
    n*=kwargs['multiply']
    print(n)

cal(2,add=5,multiply=6)