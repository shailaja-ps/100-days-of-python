from tkinter import *
window=Tk()
window.title("My first gui program")
window.minsize(width=500,height=300)

lb=Label(text="I am a label",
                 font=('ariel',24,'italic'))
lb.pack()
# renaming lb['text']='new text'
# lb.config(text='new text')
def button_click():
    print('i got clicked')
    new_text=input.get()
    lb.config(text=new_text)
button=Button(text='click me',command=button_click)
button.pack()

input=Entry(width=18)
input.pack()
print(input.get())



window.mainloop()
