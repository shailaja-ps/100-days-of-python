another_var=12
#PyPI you can find different kinds of packages here
from turtle import Turtle,Screen
#tiny is object nd Turtle is class
tinny=Turtle()
print(tinny)
tinny.shape("turtle")
tinny.color("BlueViolet")
tinny.forward(100)

my_screen=Screen()
print(my_screen.canvheight)
my_screen.exitonclick()

# import another_mod
# import turtle

# print(another_mod.another_var)