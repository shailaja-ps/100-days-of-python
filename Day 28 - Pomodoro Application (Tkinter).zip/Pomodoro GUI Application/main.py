from tkinter import *
import math

# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
timer=None

# ---------------------------- GLOBAL VARIABLES ------------------------------- #
reps = 0  # <-- Fixed

# ---------------------------- TIMER RESET ------------------------------- #
# (You'll implement this next.)
def reset_timer():
    window.after_cancel(timer)
    canvas.itemconfig(timer_text,text='00:00')
    title_label.config(text='Timer')
    check_marks.config(text="")
    global reps
    reps=0

# ---------------------------- TIMER MECHANISM ------------------------------- #
def start_timer():
    global reps
    reps += 1

    work_sec = WORK_MIN * 60
    short_break_sec = SHORT_BREAK_MIN * 60
    long_break_sec = LONG_BREAK_MIN * 60

    if reps % 8 == 0:
        title_label.config(text="Break", fg=RED)
        count_down(long_break_sec)

    elif reps % 2 == 0:
        title_label.config(text="Break", fg=PINK)
        count_down(short_break_sec)

    else:
        title_label.config(text="Work", fg=GREEN)  # <-- Fixed
        count_down(work_sec)


# ---------------------------- COUNTDOWN MECHANISM ------------------------------- #
def count_down(count):
    count_min = count // 60
    count_sec = count % 60

    canvas.itemconfig(timer_text, text=f"{count_min}:{count_sec:02d}")  # <-- Fixed

    if count > 0:
        global timer
        timer=window.after(1000, count_down, count - 1)
    else:
        start_timer()

        marks = ""
        for _ in range(reps // 2):
            marks += "✓"

        check_marks.config(text=marks)


# ---------------------------- UI SETUP ------------------------------- #
window = Tk()
window.title("Pomodoro")
window.config(padx=100, pady=50, bg="#CCCCFF")

title_label = Label(
    text="Timer",
    fg="#A76EEE",
    font=(FONT_NAME, 45),
    bg="#CCCCFF"
)
title_label.grid(column=1, row=0)

canvas = Canvas(
    width=200,
    height=224,
    bg="#CCCCFF",
    highlightthickness=0
)

tomato_img = PhotoImage(
    file=r"C:\Users\malli\OneDrive\Desktop\100 days of python\day 28\tomato.png"
)

canvas.create_image(100, 112, image=tomato_img)

timer_text = canvas.create_text(
    100,
    130,
    text="00:00",
    fill="white",
    font=(FONT_NAME, 35, "bold")
)

canvas.grid(column=1, row=1)

start_button = Button(
    text="Start",
    command=start_timer
)
start_button.grid(column=0, row=2)

reset_button = Button(
    text="Reset",command=reset_timer
)
reset_button.grid(column=2, row=2)

check_marks = Label(  # <-- Fixed
    text="",
    fg=GREEN,
    bg="#CCCCFF"
)
check_marks.grid(column=1, row=3)

window.mainloop()