from turtle import Turtle,Screen
import random
import turtle as t
tinny=Turtle()
t.colormode(255)
tinny.shape('turtle')
tinny.color('BlueViolet')

def random_color():
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    color=(r,g,b)
    return color
tinny.speed('fastest')

def draw(size_of_gap):
    for _ in range(int(360/size_of_gap)):
        
        tinny.color(random_color())
        tinny.circle(100)
        tinny.setheading(tinny.heading()+size_of_gap)

draw(5)
screen=Screen()
screen.exitonclick()