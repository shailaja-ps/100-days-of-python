from turtle import Turtle,Screen
import turtle as t
import random
tinny=Turtle()
t.colormode(255)
tinny.shape('turtle')
tinny.color('BlueViolet')

def random_color():
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    random_color=(r,g,b)
    return random_color

direction=[8,98,188,278]
#colors=["Blue","Red","Orange"]

for i in range (20):
    tinny.color(random_color())
    tinny.forward(38)
    tinny.setheading(random.choice(direction))
    

screen=Screen()
screen.exitonclick()