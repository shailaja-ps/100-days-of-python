from turtle import Turtle,Screen
tinny=Turtle()
tinny.shape('turtle')
tinny.color('BlueViolet')
def forward():
    tinny.forward(100)
def right():
    tinny.right(90)

for i in range(4):
    forward()
    right()

screen=Screen()
screen.exitonclick()