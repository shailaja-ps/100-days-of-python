from turtle import Turtle,Screen
tinny=Turtle()
tinny.shape('turtle')
tinny.color('BlueViolet')

for i in range(15):
    tinny.forward(10)
    tinny.penup()
    tinny.forward(10)
    tinny.pendown()

screen=Screen()
screen.exitonclick()