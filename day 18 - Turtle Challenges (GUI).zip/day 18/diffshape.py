from turtle import Turtle,Screen
tinny=Turtle()
tinny.shape('turtle')
tinny.color('BlueViolet')

def draw_shape(num_sides):
    angle=360/num_sides
    for _ in range(num_sides):
        tinny.forward(100)
        tinny.right(angle)

for i in range(3,11):
    draw_shape(i)


screen=Screen()
screen.exitonclick()